1. How to run the test suite.

1.1 Run test suite the on IDE (Technical audience)

- To execute test suite see "Runner" png file which outlines the steps to take to run the test suite

1) Click automation solution project name
2) Click package "com.takeaway.assessment.Runner" to expand and view CucumberRunnerTest class
3) Click on the CucumberRunnerTest class
4) Right click anywhere and Run as TestNG Test

1.2 Run test suite continuous integration tool (Non Technical and Technical audience)

- To execute test suite see "Running through Jenkins" Pt1 and Pt2 png file which outlines the steps to take to run the test sui

* PT 1

0) Launch Jenkins server url
1) Type in username
2) Type in password
3) Click Sign in

* PT 2

1) Check your Project Name
2) Click timer icon (which will build your tests)


2. How to access the generated report.

2.1 After every execution a report an extent report is generated.

1) Click automation solution project name
2) Click Reports folder to expand
3) Click "Run" html which is time stamped. (this file can be viewed on a browser)
4) Should see html content
	